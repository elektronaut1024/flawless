flawless
========

A callback factory which splits away handling errors into a separate flow and thus requiring less boilerplate code.
